window.addEventListener("load", function () {
    let pozycje = ["10:10"];
    let Ruszanie;
    let punkt
    let obraz_glowy
    let obraz_ogon = "W"
    let punkt_obrotu = []
    let zezwolenie = true
    let prev_key
    function Pozycja(klawisz) {

        let plansza = document.getElementById("plansza");
        let divy = plansza.children;
        clearInterval(Ruszanie);
        Ruszanie = setInterval(() => {
            let temp_pozycje = pozycje
            let przesunieta_pozycja;

            console.log(punkt_obrotu);

            switch (klawisz) {
                case 'KeyW':
                    przesunieta_pozycja = temp_pozycje[0].split(":");
                    przesunieta_pozycja[0] = parseInt(przesunieta_pozycja[0]) - 1;
                    prev_key = "KeyS"
                    obraz_glowy = "W"
                    break;
                case 'KeyA':
                    przesunieta_pozycja = temp_pozycje[0].split(":");
                    przesunieta_pozycja[1] = parseInt(przesunieta_pozycja[1]) - 1;
                    prev_key = "KeyD"
                    obraz_glowy = "A"
                    break;
                case 'KeyD':
                    przesunieta_pozycja = temp_pozycje[0].split(":");
                    przesunieta_pozycja[1] = parseInt(przesunieta_pozycja[1]) + 1;
                    prev_key = "KeyA"
                    obraz_glowy = "D"
                    break;
                case 'KeyS':
                    przesunieta_pozycja = temp_pozycje[0].split(":");
                    przesunieta_pozycja[0] = parseInt(przesunieta_pozycja[0]) + 1;
                    prev_key = "KeyW"
                    obraz_glowy = "S"
                    break;
            }

            temp_pozycje.unshift(przesunieta_pozycja.join(":"));
            temp_pozycje.pop();
            for (let y = 0; y < divy.length; y++) {
                divy[y].classList.remove("glowa", "cialo", "tyl");
            }

            if (pozycje.length > 1 && punkt_obrotu[0] != undefined) {
                if (pozycje[pozycje.length - 1] == punkt_obrotu[0]["id"]) {
                    obraz_ogon = punkt_obrotu[0]["kierunek"]
                    punkt_obrotu.shift()
                }
            }

            for (let i = 0; i < temp_pozycje.length; i++) {
                let obecne_pole = document.getElementById(`${temp_pozycje[i]}`);
                if (i === 0) {
                    obecne_pole.classList.add("glowa");
                    document.getElementsByClassName('glowa')[0].style.backgroundImage = `url("./obrazy/glowa_${obraz_glowy}.png")`
                } else if (i === temp_pozycje.length - 1) {
                    obecne_pole.classList.add("tyl");
                    document.getElementsByClassName('tyl')[0].style.backgroundImage = `url("./obrazy/tyl_${obraz_ogon}.png")`
                } else {
                    obecne_pole.classList.add("cialo");
                }
            }
            pozycje = temp_pozycje;
            let row = pozycje[0].split(":")[0]
            let col = pozycje[0].split(":")[1]



            for (let i = 0; i < divy.length; i++) {
                if (divy[i].id == pozycje[0] || divy[i].id == pozycje[pozycje.length - 1]) {
                } else {
                    divy[i].style.backgroundImage = ""
                }
            }
            if ((row == 0 || row == 20 || col == 0 || col == 20) || Body_check()) {
                alert("Przegrales hahahaha!!")
                Koniec()
            }
            if (pozycje[0] == punkt) {
                pozycje.push(punkt)
                for (let j = 0; j < divy.length; j++) {
                    if (divy[j].id == punkt) {
                        divy[j].classList.remove("jedzenie")
                        break
                    }
                }
                Losuj_jedzenie()
            }
            zezwolenie = true

        }, 100);
    }

    function Rysowanie_planszy() {
        let plansza = document.getElementById("plansza");
        for (let row = 0; row < 21; row++) {
            for (let col = 0; col < 21; col++) {
                let id = `${row}:${col}`;
                let pole = document.createElement("div");
                pole.id = id;
                if (col == 10 && row == 10) {
                    pole.classList.add("glowa")
                }
                if (row === 0 || row === 20 || col === 0 || col === 20) {
                    pole.classList.add("bariera");
                } else {
                    pole.classList.add("pole");
                }

                plansza.appendChild(pole);
            }
        }
    }

    function Ruch() {
        window.addEventListener("keydown", function (e) {
            if (zezwolenie) {
                let klawisz = e.code;
                if ((klawisz == "KeyW" || klawisz == "KeyS" || klawisz == "KeyD" || klawisz == "KeyA") && prev_key != klawisz) {
                    if (pozycje.length > 1) {
                        punkt_obrotu.push({ id: pozycje[0], kierunek: klawisz[3] })
                    }
                    zezwolenie = false
                    Pozycja(klawisz);
                }
            }
        });
    }

    function Losuj_jedzenie() {
        let plansza = document.getElementById("plansza")
        let divy = plansza.children
        let row = Math.floor(Math.random() * 19) + 1
        let col = Math.floor(Math.random() * 19) + 1
        let id = row + ":" + col
        if (pozycje.includes(id)) {
            Losuj_jedzenie()
        } else {
            for (let i = 0; i < divy.length; i++) {
                if (divy[i].id == id) {
                    divy[i].classList.add("jedzenie")
                    punkt = id
                    break
                }
            }
        }
    }

    function Koniec() {
        location.reload()
    }

    function Body_check() {
        let glowa = pozycje[0]
        for (let i = 1; i < pozycje.length; i++) {
            if (pozycje[i] == glowa) {
                return 1
            }
        }
        return 0
    }

    Rysowanie_planszy();
    Ruch();
    Losuj_jedzenie()
});